=====
Usage
=====

To use OWL2Vec-Star in a project::

    import owl2vec_star
